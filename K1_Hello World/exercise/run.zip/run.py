def say_hello(name):
    """Returns a string saying 'Hello $name!'"""
    return(f'Hello {name}!')


if __name__ == '__main__':
    print(say_hello("GruML"))
